@extends('layouts.client_portal_custom')
<style>
    .chart-area,
    .chart-pie {
        height: 400px;
        /* same height for both */
    }

    canvas {
        max-height: 100% !important;
    }
</style>
@section('content')
@endsection
