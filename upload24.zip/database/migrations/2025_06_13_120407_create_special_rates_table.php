<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('special_rates', function (Blueprint $table) {
            $table->id();
            $table->integer("approvedBy")->nullable();
            $table->foreignId('added_by')->constrained('users', 'id')->onDelete('cascade');
            $table->string("routeFrom")->nullable();
            $table->string("zone")->nullable();
            $table->string("origin")->nullable();
            $table->string("destination")->nullable();
            $table->integer("rate")->default(0);
            $table->decimal('additional_cost_per_kg', 10, 2)->nullable();
            $table->string('type')->nullable();
            $table->dateTime("applicableFrom")->nullable();
            $table->dateTime("applicableTo")->nullable();
            $table->string("status")->default("active");
            $table->string("approvalStatus")->default("approved");
            $table->foreignId('client_id');
            $table->foreignId('office_id');
            $table->foreignId('zone_id')->nullable();
            $table->dateTime("dateApproved")->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('special_rates');
    }
};
