<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class parcel_arrivals extends Model
{
    //
}
