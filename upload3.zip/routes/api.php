<?php
use App\Http\Controllers\TrackController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\API\ClientAuthController;
use App\Http\Controllers\GuestController;

// Route::get('/track/{requestId}', [TrackController::class, 'getTrackingByRequestId']);

// Route::get('/track/{requestId}/pdf', [TrackController::class, 'generateTrackingPdf']);

// Route::get('/tracker', [TrackController::class, 'index']);




    
// });

