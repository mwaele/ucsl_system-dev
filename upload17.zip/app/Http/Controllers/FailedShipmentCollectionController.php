<?php

namespace App\Http\Controllers;

use App\Models\FailedShipmentCollection;
use Illuminate\Http\Request;

class FailedShipmentCollectionController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(FailedShipmentCollection $failedShipmentCollection)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(FailedShipmentCollection $failedShipmentCollection)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, FailedShipmentCollection $failedShipmentCollection)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(FailedShipmentCollection $failedShipmentCollection)
    {
        //
    }
}
