<div class="section">
  <div class="section-header">6. BILLING INSTRUCTIONS</div>
  <div class="section-body">
    <div class="row">
      <div class="col">
        <label>Billing Party:</label> <span class="value">{{ $collection->billing_party ?? '' }} to pay.</span>
      </div>
    </div>
  </div>
</div>
