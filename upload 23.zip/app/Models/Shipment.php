<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Shipment extends Model
{
    //
    public function driver()
    {
        return $this->belongsTo(Driver::class);
    }
}
