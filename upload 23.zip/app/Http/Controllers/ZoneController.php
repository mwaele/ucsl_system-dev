<?php

namespace App\Http\Controllers;

use App\Models\Zone;
use App\Models\UserLog;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ZoneController extends Controller
{
    /**
     * Display a listing of the zones.
     */
    public function index(Request $request)
    {
        $zones = Zone::all();

        $currentModule = 'zone module';
        $previousModule = session('current_module');

        session(['current_module' => $currentModule]);
         // Log new module access
        UserLog::create([
            'name'    => Auth::user()->name,
            'actions' => 'Accessed ' . $currentModule,
            'table'   => "zones",
            'url'     => request()->fullUrl(),
            'user_id' => Auth::id(),
        ]);

        if ($previousModule && $previousModule !== $currentModule) {
            UserLog::create([
                'name'    => Auth::user()->name,
                'actions' => 'Exited ' . $previousModule,
                'url'     => request()->fullUrl(),
                'table'   => "zones",
                'user_id' => Auth::id(),
            ]);
        }

        return view('zones.index', compact('zones'));
    }

    /**
     * Store a newly created zone in storage.
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'zone_name' => 'required|string|max:255',
            'description' => 'required|string|max:500',
        ]);

        $zone = Zone::create($validated);;

        UserLog::create([
            'name'         => Auth::user()->name,
            'actions'      => 'Created a zone',
            'url'          => $request->fullUrl(),
            'reference_id' => $zone->id,
            'table'        => "zones",
            'user_id'      => Auth::id(),
        ]);

        return redirect()->route('zones.index')->with('success', 'Zone created successfully.');
    }

    /**
     * Update the specified zone in storage.
     */
    public function update(Request $request, $id)
    {
        $validated = $request->validate([
            'zone_name' => 'required|string|max:255',
            'description' => 'required|string|max:500',
        ]);

        $zone = Zone::findOrFail($id);
        $zone->update($validated);

        UserLog::create([
            'name'         => Auth::user()->name,
            'actions'      => 'Updated a zone (' . $request->zone_name . ')',
            'url'          => $request->fullUrl(),
            'reference_id' => $zone->id,
            'table'        => "zones",
            'user_id'      => Auth::id(),
        ]);

        return redirect()->route('zones.index')->with('success', 'Zone updated successfully.');
    }

    /**
     * Remove the specified zone from storage.
     */
    public function destroy(Request $request, $id)
    {
        $zone = Zone::findOrFail($id);
        $zone->delete();

        UserLog::create([
            'name'         => Auth::user()->name,
            'actions'      => 'Deleted a zone',
            'url'          => $request->fullUrl(),
            'reference_id' => $zone->id,
            'table'        => "zones",
            'user_id'      => Auth::id(),
        ]);

        return redirect()->route('zones.index')->with('success', 'Zone deleted successfully.');
    }

    public function checkZone(Request $request)
    {
        $exists = Zone::where('station_name', $request->station_name)->exists();
        return response()->json(['exists' => $exists]);
    }
}

