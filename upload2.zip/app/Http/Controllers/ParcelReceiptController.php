<?php

namespace App\Http\Controllers;

use App\Models\ParcelReceipt;
use Illuminate\Http\Request;

class ParcelReceiptController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(ParcelReceipt $parcelReceipt)
    {
        //dd($parcelReceipt);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(ParcelReceipt $parcelReceipt)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, ParcelReceipt $parcelReceipt)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(ParcelReceipt $parcelReceipt)
    {
        //
    }

    //payment generate receipt
    public function generateReceipt($id){


    }
}
